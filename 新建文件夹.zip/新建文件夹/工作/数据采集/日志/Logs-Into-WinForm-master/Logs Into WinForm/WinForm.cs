﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Logs_Into_WinForm
{
    public partial class WinForm : Form
    {

        public WinForm()
        {
            InitializeComponent();
            lvwColumnSorter = new ListViewColumnSorter();
            this.ListView_Message.ListViewItemSorter = lvwColumnSorter;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ListView_Message.View = View.Details;
            ListView_Message.GridLines = true;
            ListView_Message.FullRowSelect = true;
            ListView_Message.Columns.Add("Transmitted/Received", 100); // self-explanatory
            ListView_Message.Columns.Add("Message ID", 100); // e.g.: 1=TACTICAL,2=TACTICAL_MANUAL,4=TEXT etc.
            ListView_Message.Columns.Add("UnqID", 100); // e.g.: 0x0d2a2f00
            ListView_Message.Columns.Add("Date and Time", 100); // self-explanatory
            ListView_Message.Columns.Add("Length", 100); // self-explanatory
            //ListView_Message.Columns.Add("Message as \"Symbol Text\"", 100); // e.g.: ......FLTROUTE...!..../...BBU.A<ys
            Save_File_Button.Enabled = false;
            // Get colors and add them to the ComboBoxes.
            foreach (Color color in new ColorConverter().GetStandardValues())
            {
                string color_name = color.ToString().Replace("Color [", "").Replace("]", "");
                ComboBox_Color_Received.Items.Add(new ComboBoxItem(color_name, color));
                ComboBox_Color_Transmitted.Items.Add(new ComboBoxItem(color_name, color));
            }
        }
        private void OpenFileDialog_FileOk(object sender, CancelEventArgs e)
        { }
        private void SaveFileDialog_FileOk(object sender, CancelEventArgs e)
        { }
        private void Select_File_Button_Click(object sender, EventArgs e)
        {
            Stream myStream;
            OpenFileDialog OpenFileDialog = new OpenFileDialog();
            OpenFileDialog.InitialDirectory = "c:\\";
            OpenFileDialog.Filter = "log files (*.log)|*.log";
            OpenFileDialog.FilterIndex = 2;
            OpenFileDialog.RestoreDirectory = true;
            if (OpenFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = OpenFileDialog.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            string path = OpenFileDialog.FileName;
                            List<Message> messages = Extract_from_Log_File(path);
                            foreach (Message msg in messages)
                            {
                                ListViewItem listviewitem = msg.To_ListViewItem();
                                listviewitem.Tag = msg;
                                if (((Message)listviewitem.Tag).Direction == "Received")
                                {
                                    listviewitem.ForeColor = ComboBox_Color_Received.ForeColor;
                                }
                                else if (((Message)listviewitem.Tag).Direction == "Transmitted")
                                {
                                    listviewitem.ForeColor = ComboBox_Color_Transmitted.ForeColor;
                                }
                                ListView_Message.Items.Add(listviewitem);
                            }
                            messages.Clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }

            for (int i = 0; i < ListView_Message.Columns.Count - 1; i++)
            {
                ListView_Message.AutoResizeColumn(i, ColumnHeaderAutoResizeStyle.ColumnContent);
            }
        }
        private void Save_File_Button_Click(object sender, EventArgs e)
        {
            BinaryWriter binary_writer;
            SaveFileDialog SaveFileDialog = new SaveFileDialog();
            SaveFileDialog.InitialDirectory = "C:\\";
            SaveFileDialog.FilterIndex = 2;
            SaveFileDialog.RestoreDirectory = true;
            try
            {
                if (((Message)ListView_Message.SelectedItems[0].Tag).ID == "TACTICAL_MANUAL" ||
                    ((Message)ListView_Message.SelectedItems[0].Tag).ID == "TACTICAL")
                { 
                    SaveFileDialog.Filter = "odl files (*.odl)|*.odl";
                    SaveFileDialog.FileName = ((Message)ListView_Message.SelectedItems[0].Tag).FileName;
                }
                else if (((Message)ListView_Message.SelectedItems[0].Tag).ID == "TEXT")
                {
                    SaveFileDialog.Filter = "text files (*.txt)|*.txt";
                    SaveFileDialog.FileName = "";
                }
                else
                {
                    SaveFileDialog.FileName = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (SaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (binary_writer = new BinaryWriter(File.Open(SaveFileDialog.FileName, FileMode.Create)))
                    {
                        foreach (int item in ((Message)ListView_Message.SelectedItems[0].Tag).DataAsIntegers)
                        {
                            binary_writer.Write((byte)item);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Problem writing into binary file. Exception thrown: " + ex.Message);
                }
            }
        }
        private void ListView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == lvwColumnSorter.SortColumn)
            {
                if (lvwColumnSorter.Order == SortOrder.Ascending)
                {
                    lvwColumnSorter.Order = SortOrder.Descending;
                }
                else
                {
                    lvwColumnSorter.Order = SortOrder.Ascending;
                }
            }
            else
            {
                lvwColumnSorter.SortColumn = e.Column;
                lvwColumnSorter.Order = SortOrder.Ascending;
            }
            this.ListView_Message.Sort();
        }
        private void ListView_MouseClick(object sender, MouseEventArgs e)
        {
            if (((Message)ListView_Message.SelectedItems[0].Tag).ID == "USER_ACK" ||
                ((Message)ListView_Message.SelectedItems[0].Tag).ID == "")
            {
                Save_File_Button.Enabled = false;
            }
            else
            {
                Save_File_Button.Enabled = true;
            }
            TextBox_Message.Text = ((Message)ListView_Message.SelectedItems[0].Tag).SymbolText;
            //Debug code(s):
            //textBox1.Text = listView2.SelectedIndices[0].ToString();
        }
        private void ComboBox_Color_Received_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox_Color_Received.ForeColor = Color.FromName(ComboBox_Color_Received.Items[ComboBox_Color_Received.SelectedIndex].ToString().Replace("Color [", "").Replace("]", ""));
            if (ListView_Message.Items.Count != 0)
            {
                foreach (ListViewItem item in ListView_Message.Items)
                {
                    if (((Message)item.Tag).Direction == "Received")
                    {
                        item.SubItems[0].ForeColor = ComboBox_Color_Received.ForeColor;
                    }
                }
            }
            ListView_Message.Select();
        }
        private void ComboBox_Color_Transmitted_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox_Color_Transmitted.ForeColor = Color.FromName(ComboBox_Color_Transmitted.Items[ComboBox_Color_Transmitted.SelectedIndex].ToString().Replace("Color [", "").Replace("]", ""));
            if (ListView_Message.Items.Count != 0)
            {
                foreach (ListViewItem item in ListView_Message.Items)
                {
                    if (((Message)item.Tag).Direction == "Transmitted")
                    {
                        item.SubItems[0].ForeColor = ComboBox_Color_Transmitted.ForeColor;
                    }
                }
            }
            ListView_Message.Select();
        }

    }
}
