﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Logs_Into_WinForm
{
    partial class WinForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListView_Message = new System.Windows.Forms.ListView();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.Select_File_Button = new System.Windows.Forms.Button();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.Save_File_Button = new System.Windows.Forms.Button();
            this.ComboBox_Color_Received = new Logs_Into_WinForm.ComboBoxCustom();
            this.ComboBox_Color_Transmitted = new Logs_Into_WinForm.ComboBoxCustom();
            this.TextBox_Message = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ListView_Message
            // 
            this.ListView_Message.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ListView_Message.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListView_Message.GridLines = true;
            this.ListView_Message.Location = new System.Drawing.Point(12, 137);
            this.ListView_Message.Name = "ListView_Message";
            this.ListView_Message.Size = new System.Drawing.Size(795, 479);
            this.ListView_Message.TabIndex = 7;
            this.ListView_Message.UseCompatibleStateImageBehavior = false;
            this.ListView_Message.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ListView_ColumnClick);
            this.ListView_Message.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ListView_MouseClick);
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "OpenFileDialog";
            this.OpenFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog_FileOk);
            // 
            // Select_File_Button
            // 
            this.Select_File_Button.Location = new System.Drawing.Point(12, 12);
            this.Select_File_Button.Name = "Select_File_Button";
            this.Select_File_Button.Size = new System.Drawing.Size(146, 51);
            this.Select_File_Button.TabIndex = 1;
            this.Select_File_Button.Text = "Select File";
            this.Select_File_Button.UseVisualStyleBackColor = true;
            this.Select_File_Button.Click += new System.EventHandler(this.Select_File_Button_Click);
            // 
            // SaveFileDialog
            // 
            this.SaveFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.SaveFileDialog_FileOk);
            // 
            // Save_File_Button
            // 
            this.Save_File_Button.Location = new System.Drawing.Point(12, 69);
            this.Save_File_Button.Name = "Save_File_Button";
            this.Save_File_Button.Size = new System.Drawing.Size(146, 51);
            this.Save_File_Button.TabIndex = 8;
            this.Save_File_Button.Text = "Save Message";
            this.Save_File_Button.UseVisualStyleBackColor = true;
            this.Save_File_Button.Click += new System.EventHandler(this.Save_File_Button_Click);
            // 
            // ComboBox_Color_Received
            // 
            this.ComboBox_Color_Received.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ComboBox_Color_Received.FormattingEnabled = true;
            this.ComboBox_Color_Received.Location = new System.Drawing.Point(164, 24);
            this.ComboBox_Color_Received.Name = "ComboBox_Color_Received";
            this.ComboBox_Color_Received.Size = new System.Drawing.Size(242, 27);
            this.ComboBox_Color_Received.TabIndex = 9;
            this.ComboBox_Color_Received.Text = "Choose Color for Received";
            this.ComboBox_Color_Received.SelectedIndexChanged += new System.EventHandler(this.ComboBox_Color_Received_SelectedIndexChanged);
            // 
            // ComboBox_Color_Transmitted
            // 
            this.ComboBox_Color_Transmitted.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ComboBox_Color_Transmitted.FormattingEnabled = true;
            this.ComboBox_Color_Transmitted.Location = new System.Drawing.Point(164, 81);
            this.ComboBox_Color_Transmitted.Name = "ComboBox_Color_Transmitted";
            this.ComboBox_Color_Transmitted.Size = new System.Drawing.Size(242, 27);
            this.ComboBox_Color_Transmitted.TabIndex = 10;
            this.ComboBox_Color_Transmitted.Text = "Choose Color for Transmitted";
            this.ComboBox_Color_Transmitted.SelectedIndexChanged += new System.EventHandler(this.ComboBox_Color_Transmitted_SelectedIndexChanged);
            // 
            // TextBox_Message
            // 
            this.TextBox_Message.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TextBox_Message.BackColor = System.Drawing.Color.White;
            this.TextBox_Message.Location = new System.Drawing.Point(412, 12);
            this.TextBox_Message.Multiline = true;
            this.TextBox_Message.Name = "TextBox_Message";
            this.TextBox_Message.ReadOnly = true;
            this.TextBox_Message.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBox_Message.Size = new System.Drawing.Size(395, 108);
            this.TextBox_Message.TabIndex = 12;
            // 
            // WinForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 628);
            this.Controls.Add(this.ListView_Message);
            this.Controls.Add(this.TextBox_Message);
            //this.Controls.Add(this.ComboBox_Color_Transmitted);
            //this.Controls.Add(this.ComboBox_Color_Received);
            this.Controls.Add(this.Save_File_Button);
            this.Controls.Add(this.Select_File_Button);
            this.Name = "WinForm";
            this.Text = "Logs into WinForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.Button Select_File_Button;
        private System.Windows.Forms.Button Save_File_Button;
        private ComboBoxCustom ComboBox_Color_Received;
        private ComboBoxCustom ComboBox_Color_Transmitted;
        private System.Windows.Forms.TextBox TextBox_Message;
        private System.Windows.Forms.ListView ListView_Message;
        ListViewColumnSorter lvwColumnSorter;
    }
}

