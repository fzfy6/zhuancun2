﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;

namespace Logs_Into_WinForm
{
    class Message
    {
        private static int counter;
        
        private int _message_number;
        public int MessageNumber
        {
            get { return _message_number; }
        }

        private string _direction;
        public string Direction
        {
            get { return _direction; }
        }

        private string _ID;
        public string ID
        {
            get { return _ID; }
        }

        private string _unqID;
        public string UnqID
        {
            get { return _unqID; }
        }

        private string _date;
        public string Date
        {
            get { return _date;  }
        }

        private string _time;
        public string Time
        {
            get { return _time; }
        }

        private string _file_name;
        public string FileName
        {
            get { return _file_name;  }
        }

        private string _symbol_text;
        public string SymbolText
        {
            get { return _symbol_text; }
        }

        private string _date_and_time;
        public string DateAndTime
        {
            get { return _date_and_time; }
        }

        private int _length;
        public int Length
        {
            get { return _length; }
        }

        private List<string> _lst = new List<string>();

        private List<int> _data_as_integers = new List<int>();
        public List<int> DataAsIntegers
        {
            get { return _data_as_integers; }
        }

        public Message(string new_direction, string new_ID, string new_unqID,
            string new_date, string new_time, string new_file_name, string new_symbol_text, List<int> new_data_as_integers, int new_length)
        {
            this._direction = new_direction;
            this._ID = new_ID;
            this._unqID = new_unqID;
            this._date = new_date;
            this._time = new_time;
            this._file_name = new_file_name;
            this._symbol_text = new_symbol_text;
            this._message_number = counter;
            this._data_as_integers = new_data_as_integers;
            this._length = new_length;
            this._date_and_time = this._date + " " + this._time;
            this.To_List();
            counter++;
            
        }

        public void Print()
        {
            foreach (string item in _lst)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
        }

        private void To_List()
        {
            _lst.Add(this._direction);
            _lst.Add(this._ID);
            _lst.Add(this._unqID);
            _lst.Add(this._date_and_time);
            _lst.Add(this._length.ToString());
            //lst.Add(this.message);
        }

        public ListViewItem To_ListViewItem()
        {
            string[] arr_of_str = new string[_lst.Count];
            for (int i = 0; i < _lst.Count; i++)
            {
                arr_of_str[i] = _lst[i];
            }
            ListViewItem listviewitem = new ListViewItem(arr_of_str);
            return listviewitem;
        }

    }
}
