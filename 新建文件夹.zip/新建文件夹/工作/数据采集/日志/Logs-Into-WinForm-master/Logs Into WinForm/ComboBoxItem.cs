﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Logs_Into_WinForm
{
    public class ComboBoxItem
    {
        public string text = "";
        public string Text
        {
            get { return text; } set { text = value; }
        }

        public Color fore_colour;
        public Color Fore_Color
        {
            get { return fore_colour; }
            set { fore_colour = value; }
        }

        public ComboBoxItem (string new_text, Color new_color)
        {
            this.text = new_text;
            this.fore_colour = new_color;
        }

        public override string ToString()
        {
            return this.fore_colour.ToString().Replace("Color [", "").Replace("]", "");
        }
    }
}
