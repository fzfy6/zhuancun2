# VisualLogger
一个简单的WinForm日志工具.P话不多说,直接上代码.

调用方式:
<pre><code>
private static void Main()
{
    var targetLogFile = new FileInfo($"./{DateTime.Now:yyyy-mm-dd}Test.log");
    Console.WriteLine("将日志项写入:\r\n" + targetLogFile.FullName);
    VLogger.LogToConsole = true; // 将日志项打印到控制台(可选)
    VLogger.Start(targetLogFile); // 如果您跳过初始化,将会报错
    try
    {
        var log = new VLogger(typeof(Program)); // 创建具有类名的记录器
        var tasks = new List<Task>();
        for (var i = 1; i < 2; i++)
        {
            log.Info("启动线程: " + i);
            tasks.Add(Task.Factory.StartNew(() => LogMessages(i)));
        }
        Task.WaitAll(tasks.ToArray());
        log.Debug("这是一个Debug");
        log.Warning("这是一个Warning");
        log.Info("这是一个Info");
        var x = 0;
        try
        {
            x = int.Parse("测试使用的字符串");
        }
        catch (Exception ex)
        {
            log.Error(x + "这是一个Erroe", ex);
        }
        log.LogMessageAdded += Log_LogMessageAdded;
    }
    finally
    {
        try
        {
            MultiPrames(1, 2, "256");
        }
        finally
        {
            VLogger.ShutDown(); // 不关闭可能会导致日志丢失
        }
    }
    Console.WriteLine("完成.");
    Console.ReadKey();
}

private static void Log_LogMessageAdded(object sender, VLogMessageInfo e) =>
    throw new NotImplementedException("这里可以取到VLogMessageInfo的一些属性");

private static void MultiPrames(int x, int y, string rsc)
{
    var log = new VLogger(typeof(Program));
    try
    {
        var x1 = x;
        var y1 = y;
        var rsc1 = int.Parse(rsc);
        var z = x1 + y1 + rsc1;
        throw new Exception("多个参数报错" + z);
    }
    catch (Exception ex)
    {
        log.Error(ex.Message, ex);
    }
}

private static void LogMessages(int threadId)
{
    var log = new VLogger("线程:" + threadId); // 从字符串创建
    for (var i = 1; i < 2; i++)
    {
        log.Info("这是日志信息" + i);
        Thread.Sleep(new Random().Next(10, 100)); // 模拟更现实的执行
    }
}
</code></pre>

测试效果:
<pre><code>
2017-12-01 16:31:31.157	 1	 Program	 INFO	 VisualLoggerTest.Program.Mai)	 启动线程: 1

2017-12-01 16:31:31.169	 4	 线程:2	 INFO	 VisualLoggerTest.Program.LogMessages(Int32 threadId)	 这是日志信息1

2017-12-01 16:31:31.232	 1	 Program	 DEBUG	 VisualLoggerTest.Program.Mai)	 这是一个Debug

2017-12-01 16:31:31.232	 1	 Program	 WARNING	 VisualLoggerTest.Program.Mai)	 这是一个Warning

2017-12-01 16:31:31.232	 1	 Program	 INFO	 VisualLoggerTest.Program.Mai)	 这是一个Info

2017-12-01 16:31:31.248	 1	 Program	 ERROR	 VisualLoggerTest.Program.Mai)	 0这是一个Erroe
输入字符串的格式不正确。
   在 System.Number.StringToNumber(String str, NumberStyles options, NumberBuffer& number, NumberFormatInfo info, Boolean parseDecimal)
   在 System.Number.ParseInt32(String s, NumberStyles style, NumberFormatInfo info)
   在 VisualLoggerTest.Program.Main() 位置 C:\Users\Dyu\Source\Repos\VisualLogger\VisualLogger\VisualLoggerTest\Program.cs:行号 31

2017-12-01 16:31:31.248	 1	 Program	 ERROR	 VisualLoggerTest.Program.MultiPrames(Int32 x, Int32 y, String rsc)	 多个参数报错259
多个参数报错259
   在 VisualLoggerTest.Program.MultiPrames(Int32 x, Int32 y, String rsc) 位置 C:\Users\Dyu\Source\Repos\VisualLogger\VisualLogger\VisualLoggerTest\Program.cs:行号 69
</code></pre>
