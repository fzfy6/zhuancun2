﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Miraclesoft.VisualLogger;

namespace VisualLoggerTest
{
    internal class Program
    {
        private static void Main()
        {
            
            string str = string.Format("{0:yyyy-MM-dd HH.mm.ss.ffff}", DateTime.Now);
            var targetLogFile = new FileInfo($"./Log/{str}Test.log");
            Console.WriteLine("将日志项写入:\r\n" + targetLogFile.FullName);
            VLogger.LogToConsole = true; // 将日志项打印到控制台(可选)
            var log = new VLogger(typeof(Program)); // 创建具有类名的记录器
            try
            {                
                log.Start(targetLogFile); // 如果您跳过初始化,将会报错

                var tasks = new List<Task>();
                for (var i = 1; i < 2; i++)
                {
                    log.Info("启动线程: " + i);
                    tasks.Add(Task.Factory.StartNew(() => LogMessages(i)));
                }
                Task.WaitAll(tasks.ToArray());
                log.Debug("这是一个Debug");
                log.Warning("这是一个Warning");
                log.Info("这是一个Info");
                var x = 0;
                try
                {
                    x = int.Parse("测试使用的字符串");
                }
                catch (Exception ex)
                {
                    log.Error(x + "这是一个Erroe", ex);
                }
                log.LogMessageAdded += Log_LogMessageAdded;
            }
            finally
            {
                try
                {
                    MultiPrames(1, 2, "256");
                }
                finally
                {
                    log.ShutDown(); // 不关闭可能会导致日志丢失
                }
            }
            Console.WriteLine("完成.");
            Console.ReadKey();
        }

        private static void Log_LogMessageAdded(object sender, VLogMessageInfo e) =>
            throw new NotImplementedException("这里可以取到VLogMessageInfo的一些属性");

        private static void MultiPrames(int x, int y, string rsc)
        {
            var log = new VLogger(typeof(Program));
            try
            {
                var x1 = x;
                var y1 = y;
                var rsc1 = int.Parse(rsc);
                var z = x1 + y1 + rsc1;
                throw new Exception("多个参数报错" + z);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message, ex);
            }
        }

        private static void LogMessages(int threadId)
        {
            var log = new VLogger("线程:" + threadId); // 从字符串创建
            for (var i = 1; i < 2; i++)
            {
                log.Info("这是日志信息" + i);
                Thread.Sleep(new Random().Next(10, 100)); // 模拟更现实的执行
            }
        }
    }
}